# Web3 Trading Assignment – Trader Behavior vs Market Sentiment

**Candidate Name**: Vyshnavi Sai Sri Vissa  
**Submission Folder**: ds_vyshnavi_sai_sri_vissa  
**Date**: July 2025  

---

## Objective

Analyze how market sentiment (Fear, Greed, etc.) impacts trader behavior and profitability using:

- Bitcoin Fear & Greed Index  
- Historical Trader Data from Hyperliquid

---

## Folder Structure

ds_vyshnavi_sai_sri_vissa/
├── notebook_1.ipynb         # EDA + Sentiment Analysis  
├── notebook_2.ipynb         # Modelling + Prediction  
├── csv_files/               
│   ├── historical_data.csv  
│   ├── fear_greed_index.csv  
│   └── merged_dataset.csv  
├── outputs/                 
│   ├── sentiment_dist.png  
│   ├── pnl_by_sentiment.png  
│   ├── size_by_sentiment.png  
│   ├── correlation_heatmap.png  
│   ├── profit_by_sentiment.png  
│   └── feature_importance.png  
├── ds_report.pdf            # Final Project Report  
└── README.md                # Project Overview
